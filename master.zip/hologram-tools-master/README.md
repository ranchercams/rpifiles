# hologram-tools
The client-side tools you need to help build your next cellular-connected product

## ppp
Useful ppp chatscripts for quickly getting your USB cellular modem online

## For more information
Questions? Chat about them at: https://community.hologram.io
